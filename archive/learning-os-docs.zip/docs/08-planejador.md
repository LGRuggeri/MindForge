# 08 — Planejador (Planner)

**Status:** TODO. Módulo `planner` no backend é esqueleto.

## 1. Responsabilidade

Transforma um `objetivo_estudo` num plano de estudo executável: uma
`trilha_estudo` versionada, dividida em `modulos_trilha` ordenados. É o
primeiro agente acionado no fluxo, depois que o usuário registra um
objetivo (`perfil` → `objetivos_estudo`).

## 2. Entrada

- `objetivo_estudo`: título, descrição, nível desejado, prazo estimado.
- `perfil_aprendizagem`: nível atual, tempo disponível semanal,
  preferências.
- (Fase 2+) Competências já dominadas em `competencia_progresso`, para
  evitar replanejar do zero o que o usuário já sabe.

## 3. Saída

Uma `trilha_estudo` com `modulos_trilha` ordenados
(`04-modelagem-dados.md §3.2`), cada módulo com `titulo`,
`objetivo_aprendizagem` e `tempo_estimado_min`. O agente não gera o
conteúdo de cada módulo — isso é o `synthesizer` (`09-gerador-de-conteudo.md`).
O Planner define *o quê* estudar e *em que ordem*; o Synthesizer produz o
material em si.

## 4. Versionamento e replanejamento

`trilhas_estudo.versao` existe justamente para não perder histórico quando
o plano precisa mudar. Casos que disparam replanejamento (design, a validar
na implementação):

- O usuário edita o objetivo (nível desejado, prazo).
- Uma avaliação (`10-avaliacoes.md`) revela lacunas que o plano original não
  cobria — o `evaluator` sinaliza, o `planner` ajusta.
- O usuário pausa e retoma o objetivo depois de muito tempo — pode fazer
  sentido reavaliar o nível atual antes de continuar de onde parou.

Quando um replanejamento ocorre, a trilha antiga muda `status` para
`substituida` e uma nova linha é inserida com `versao` incrementada — nunca
um `UPDATE` destrutivo sobre a trilha existente.

## 5. Execução

Assíncrona, via `JobsModule` (ver `05-agentes-ia.md §3`) — gerar uma trilha
pode envolver uma consulta prévia ao Research Engine para entender o escopo
do assunto antes de dividir em módulos, o que não é instantâneo.

## 6. Pontos em aberto

- Quantos módulos uma trilha deve ter, por padrão? Sem número fixo definido
  — provavelmente proporcional ao `tempo_disponivel_semanal_min` do perfil
  e à complexidade do objetivo, mas o algoritmo exato só deve ser fixado ao
  testar com objetivos reais.
- O Planner consulta o Research Engine antes ou depois de definir os
  módulos? Depender de pesquisa prévia deixa o plano mais informado, mas
  adiciona latência. A decidir na implementação.
