# 10 — Exercícios e Avaliações

**Status:** TODO. Módulo `exercicios-avaliacoes` no backend é esqueleto.

## 1. Responsabilidade

Cobre dois momentos distintos do fluxo (`00-visao.md`): **Exercícios**
(prática contínua, ligada a um módulo específico) e **Avaliações**
(agrupamentos formais de exercícios — diagnóstico, prova, simulado). Ambos
compartilham o agente `evaluator`.

## 2. Exercícios

- `exercicios.tipo`: `questao_objetiva`, `dissertativa`, `codigo` ou
  `projeto` — cada tipo provavelmente exige um prompt de geração e um
  prompt de correção diferentes no `evaluator`.
- `exercicios.gabarito`: para questões objetivas, a resposta esperada; para
  dissertativas e código, mais um critério de correção do que uma resposta
  única — o `evaluator` precisa julgar por critério, não por igualdade
  exata de string.
- Cada tentativa (`tentativas_exercicio`) registra `correta`, `pontuacao` e
  `feedback_ia` — é este `feedback_ia` que implementa o "apontar erros e
  acertos" do objetivo original do projeto (`00-visao.md`).

## 3. Avaliações

Agrupam exercícios (`avaliacao_exercicios`) e geram um
`resultado_avaliacao` consolidado: pontuação total, pontos fortes, pontos
fracos e recomendações — não apenas "acertou X de Y", mas uma leitura
qualitativa do desempenho, que alimenta tanto o replanejamento
(`08-planejador.md §4`) quanto o diário (`12-diario-aprendizagem.md`).

Tipos (`avaliacoes.tipo`):

| Tipo | Quando usar |
|---|---|
| `diagnostica` | Antes de iniciar um módulo, para calibrar o nível real do usuário. |
| `formativa` | Durante o módulo, baixo peso, foco em feedback. |
| `somativa` | Ao final do módulo, valida se o objetivo de aprendizagem foi atingido. |
| `simulado` | Cobre múltiplos módulos, simula uma avaliação mais ampla. |

## 4. Relação com revisão espaçada

Uma tentativa incorreta (ou uma avaliação com pontuação baixa num tópico)
deveria alimentar `revisao_espacada` — criando ou reforçando um item de
revisão para aquele conteúdo/exercício/competência. O mecanismo exato
(quando criar um novo item vs. resetar o `intervalo_dias` de um existente)
é TODO, a decidir junto com a implementação de ambos os módulos.

## 5. Pontos em aberto

- Correção de exercícios de código: exige rodar o código de alguma forma
  (sandbox), não só o LLM julgar o texto. Isso pode significar uma
  dependência de execução isolada (ex: container efêmero) — ainda não
  avaliada, e é o tipo de decisão que só deve ser tomada quando este tipo
  de exercício for de fato implementado, não antes.
- Síncrono vs. assíncrono: ver `05-agentes-ia.md §3`.
