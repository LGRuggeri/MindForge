# 14 — Decisões Arquiteturais

Registro consolidado de todas as decisões técnicas tomadas até aqui, no
formato Contexto / Decisão / Alternativas consideradas / Consequências.
Novas decisões devem ser adicionadas a este arquivo no momento em que forem
tomadas — não em lote, depois — seguindo o princípio de documentação viva
de `01-filosofia.md`.

---

### ADR-001 — Sem Redis

**Contexto:** o stack original (`Learning_OS_Visao_v2.md`) incluía Redis.
**Decisão:** não usar Redis. Cache distribuído e pub/sub não trazem ganho
perceptível para um único usuário local; o único caso de uso real (fila de
jobs) é resolvido sobre o próprio Postgres.
**Alternativas consideradas:** Redis com BullMQ para filas.
**Consequências:** um serviço a menos para instalar e manter localmente.
Se o projeto um dia precisar de cache distribuído de verdade (não é o caso
hoje), essa decisão precisa ser revisitada.

---

### ADR-002 — Fila de jobs sobre o próprio Postgres

**Contexto:** pesquisa, síntese e correção são operações longas que não
devem bloquear a resposta HTTP.
**Decisão:** `pg-boss` ou `graphile-worker`, ambos implementados sobre
`LISTEN/NOTIFY` do Postgres.
**Alternativas consideradas:** Redis + BullMQ (descartado junto com
ADR-001); RabbitMQ/SQS (overkill para volume pessoal).
**Consequências:** sem novo serviço de infraestrutura. Throughput e
concorrência são limitados pelo Postgres, irrelevante na escala atual.
**Status:** decisão tomada, implementação ainda não feita —
`JobsModule` no backend é stub.

---

### ADR-003 — `TEXT` + `CHECK` em vez de `ENUM` nativo do Postgres

**Contexto:** o schema tem muitos campos de status/tipo fechado (`status`,
`tipo`, `nivel_atual`, etc.).
**Decisão:** representar como `TEXT` com constraint `CHECK`, não `CREATE
TYPE ... AS ENUM`.
**Alternativas consideradas:** ENUM nativo do Postgres.
**Consequências:** adicionar ou remover um valor válido é uma migration
simples (`ALTER TABLE ... DROP CONSTRAINT / ADD CONSTRAINT`), sem as
restrições históricas de alterar um ENUM nativo. Custo: nenhuma validação
de tipo em nível de banco tão forte quanto um ENUM (mitigado pela validação
de DTO na borda da API, via `class-validator`).

---

### ADR-004 — UUID como chave primária

**Contexto:** toda tabela do schema precisa de chave primária.
**Decisão:** `UUID` (`gen_random_uuid()` / `defaultRandom()` no Drizzle),
não `BIGSERIAL`.
**Alternativas consideradas:** `BIGSERIAL`.
**Consequências:** facilita merges entre ambientes, não vaza volume de
registros pela API. Índices um pouco maiores que inteiro — irrelevante na
escala de uso pessoal.

---

### ADR-005 — `revisao_espacada` polimórfica

**Contexto:** um item de revisão espaçada pode ser um `conteudo`, um
`exercicio` ou uma `competencia`.
**Decisão:** uma tabela única com `item_tipo` + `item_id`, sem FK real
(impossível ter FK que aponte para tabelas diferentes condicionalmente no
Postgres).
**Alternativas consideradas:** três tabelas separadas
(`revisao_conteudo`, `revisao_exercicio`, `revisao_competencia`), cada uma
com FK real.
**Consequências:** perde-se integridade referencial automática do Postgres
para esta tabela especificamente — um `item_id` órfão não seria pego pelo
banco. Ganha-se não ter três tabelas quase idênticas para manter. Para um
projeto solo, o trade-off vale a pena; revisitar se algum dia a
inconsistência de dados nesta tabela virar problema real.

---

### ADR-006 — HNSW em vez de IVFFlat para o índice vetorial

**Contexto:** `conteudo_chunks.embedding` precisa de índice para busca por
similaridade eficiente.
**Decisão:** índice HNSW (`vector_cosine_ops`), parâmetros padrão do
pgvector (`m=16`, `ef_construction=64`).
**Alternativas consideradas:** IVFFlat.
**Consequências:** HNSW não exige fase de treinamento prévia (IVFFlat
precisa de dados já inseridos para calcular os clusters), funciona bem
desde o primeiro chunk indexado — adequado para uma base que começa vazia e
cresce aos poucos. Se o volume crescer para centenas de milhares de chunks,
os parâmetros podem precisar de ajuste — não antes.

---

### ADR-007 — Postgres único com pgvector, sem banco vetorial dedicado

**Contexto:** o stack original citava "Qdrant ou pgvector" como opções
alternativas.
**Decisão:** um único Postgres, com a extensão `pgvector`, sem Qdrant.
**Alternativas consideradas:** Qdrant como banco vetorial separado.
**Consequências:** um componente de infraestrutura a menos para operar
localmente. Custo: uma escala de busca vetorial menor que um banco vetorial
dedicado ofereceria — irrelevante para uma biblioteca pessoal.

---

### ADR-008 — Drizzle como ORM

**Contexto:** o projeto precisa de um ORM que lide bem tanto com CRUD
relacional comum quanto com a coluna vetorial de `conteudo_chunks`, que é
consultada com alta frequência (toda resposta do Tutor IA).
**Decisão:** Drizzle ORM.
**Alternativas consideradas:**
- **Prisma** — sem suporte nativo a `vector` até o momento da decisão;
  exige `Unsupported("vector(1536)")` + SQL raw/TypedSQL para toda operação
  vetorial, e Prisma Studio não exibe essas colunas corretamente.
- **TypeORM** — ganhou suporte nativo a `vector`/`halfvec` recentemente
  (0.3.27+), mas tem histórico de instabilidade em geração de migrations e
  no padrão Active Record.
**Consequências:** a tabela mais consultada do sistema é tratada como
cidadão de primeira classe pelo ORM (`cosineDistance` tipado, direto no
query builder), não como exceção via SQL cru. Custo: sem módulo oficial
`@nestjs/drizzle` — wiring manual no `DatabaseModule`, mas é custo único.
Validado na prática: schema Drizzle gerou migration SQL sem o bug de
parametrização conhecido em `CHECK` constraints, aplicada com sucesso em
Postgres real.

---

### ADR-009 — Estrutura de módulo pragmática, sem Clean Architecture hexagonal completa

**Contexto:** o backend tem 9 módulos de domínio mapeados 1:1 com
`02-arquitetura.md`.
**Decisão:** cada módulo segue `controller → service → repository`, não as
quatro camadas completas (domain/application/infrastructure/presentation).
**Alternativas consideradas:** hexagonal completo por módulo, com
interfaces de repositório separadas da implementação.
**Consequências:** a única inversão de dependência mantida — o `service`
nunca importa `drizzle-orm` diretamente, só o `repository` — é a que
realmente paga seu custo num projeto solo. Camadas adicionais foram
avaliadas como overengineering para este contexto (ver
`learning-os-api/README.md`, seção "Padrão de módulo").

---

### ADR-010 — TypeScript 6.x fixado, não 7.x

**Contexto:** ao montar o scaffold, `typescript@7.0.2` foi instalado por
padrão (última versão disponível).
**Decisão:** fixar `typescript@^6` em `package.json`.
**Motivo:** TypeScript 7.0 ainda não expõe a API programática do compilador
que o Nest CLI usa para build/start — o próprio Nest CLI recomenda TS 6 até
que a API retorne (prevista para 7.1).
**Consequências:** nenhuma perda de funcionalidade relevante hoje. Revisitar
quando TypeScript 7.1 for lançado e o Nest CLI confirmar suporte.

---

### ADR-011 — Documentação viva em vez de especificação antecipada

**Contexto:** a proposta inicial era escrever 200–300 páginas de
documentação completa antes de qualquer código.
**Decisão:** núcleo (`00`–`04`) escrito primeiro; documentos de módulo
(`05`–`12`) escritos como especificação de design quando o módulo ainda não
tem código, e atualizados para refletir a implementação real assim que ela
existir (caso de `11-biblioteca-viva.md`, já reescrito nesse formato).
**Alternativas consideradas:** especificação completa e prescritiva antes
de qualquer implementação.
**Consequências:** parte da documentação de módulo ainda registra perguntas
em aberto em vez de respostas definitivas — isso é intencional, não uma
lacuna a preencher às pressas. Ver `01-filosofia.md`.
