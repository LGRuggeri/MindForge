# 07 — Knowledge Graph Pessoal

**Status:** modelo de dados pronto e testado (`04-modelagem-dados.md §3.8`).
Módulo `knowledge-graph` no backend é esqueleto — nenhuma lógica de
atualização de progresso implementada ainda.

## 1. Estrutura

Lista de adjacência simples sobre quatro tabelas: `competencias` (nós),
`competencia_relacoes` (arestas: `pre_requisito`, `relacionada`,
`aprofundamento`), `competencia_progresso` (nível de domínio do usuário por
competência) e `modulo_competencias` (liga módulos da trilha às
competências que desenvolvem).

A justificativa de não usar uma extensão de grafo dedicada (Apache AGE ou
similar) está registrada em `04-modelagem-dados.md §3.8` e
`14-decisoes-arquiteturais.md`.

## 2. Consulta de pré-requisitos (testada)

A consulta recursiva abaixo foi executada de verdade contra Postgres
durante a validação do schema (ver `04-modelagem-dados.md §3.8`):

```sql
WITH RECURSIVE cadeia AS (
    SELECT id, nome, ARRAY[nome] AS caminho
    FROM competencias WHERE nome = 'Rust básico'
    UNION ALL
    SELECT c.id, c.nome, cadeia.caminho || c.nome
    FROM competencia_relacoes r
    JOIN competencias c ON c.id = r.competencia_destino_id
    JOIN cadeia ON cadeia.id = r.competencia_origem_id
)
SELECT * FROM cadeia;
```

Quando o módulo `knowledge-graph` for implementado, esta consulta vira o
núcleo de um `KnowledgeGraphRepository.buscarCadeia(competenciaId)`,
seguindo o mesmo padrão de repositório dos módulos já prontos (ver
`learning-os-api/README.md`).

## 3. Como o progresso é atualizado — TODO, não implementado

Design pretendido, a validar na implementação:

1. Um módulo (`modulos_trilha`) é concluído → as competências ligadas a ele
   via `modulo_competencias` avançam de `nao_iniciado` para `aprendendo`.
2. Uma tentativa de exercício correta (`tentativas_exercicio.correta =
   true`) ligada, transitivamente via módulo, a uma competência → a
   competência avança para `praticando`.
3. Um resultado de avaliação (`resultados_avaliacao`) com boa pontuação
   cobrindo exercícios daquela competência → avança para `dominado`.

Esse fluxo depende de exercícios/avaliações estarem implementados
(`10-avaliacoes.md`) antes de fazer sentido implementar a atualização
automática do grafo. Até lá, `competencia_progresso` pode ser atualizado
manualmente ou não ser usado.

## 4. Visualização

O front-end usa **React Flow** (`03-stack-tecnologica.md`) para renderizar
o grafo. Ainda não há endpoint que sirva `competencias` +
`competencia_relacoes` em formato de nós/arestas — a definir junto com a
implementação do módulo, provavelmente uma rota GraphQL (mencionada em
`03-stack-tecnologica.md` como parte do backend) dado que o formato de
nós/arestas aninhado se beneficia de uma query mais flexível que REST puro.

## 5. Lacunas conhecidas

- Nenhuma competência foi definida ainda para o Learning OS em si — as
  linhas de `competencias` usadas na validação (seção 2) foram dados de
  teste (`Rust básico`, `Ownership`, `Lifetimes`), removidos depois.
- Quem cria as competências de uma trilha nova (`modulo_competencias`)? O
  `planner`, provavelmente, ao gerar os módulos — não decidido.
