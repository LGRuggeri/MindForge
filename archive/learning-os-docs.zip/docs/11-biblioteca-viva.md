# 11 — Biblioteca Viva

**Status:** implementado e testado. Único módulo, junto com `perfil`, com
código real no scaffold — não uma especificação de design como os
documentos anteriores.

## 1. O que existe

`modules/biblioteca-viva/` no backend:

| Arquivo | Papel | Status |
|---|---|---|
| `biblioteca-viva.repository.ts` | Indexação de chunks e busca por similaridade de cosseno | ✅ implementado, testado contra Postgres+pgvector real |
| `biblioteca-viva.service.ts` | Orquestra: gera embedding da consulta → busca chunks similares | ✅ implementado |
| `biblioteca-viva.controller.ts` | Expõe `POST /biblioteca-viva/buscar` | ✅ implementado, testado via HTTP real |
| `embedding.service.ts` | Geração de embeddings | 🚧 stub — lança erro proposital |
| `dto/buscar-semantica.dto.ts` | Validação de entrada (`consulta`, `limite`) | ✅ implementado |

## 2. Indexação

```ts
async indexarChunk(dados: NovoConteudoChunk) {
  const [chunk] = await this.db.insert(conteudoChunks).values(dados).returning();
  return chunk;
}
```

Recebe um chunk já com embedding calculado — quem decide *onde* cortar o
texto em chunks é o `synthesizer` (`09-gerador-de-conteudo.md`), ainda não
implementado. Este módulo só indexa e busca, não sintetiza.

## 3. Busca por similaridade

```ts
async buscarSimilares(embeddingConsulta: number[], limite: number) {
  const similaridade = sql<number>`1 - (${cosineDistance(
    conteudoChunks.embedding,
    embeddingConsulta,
  )})`;

  return this.db
    .select({ id, texto, conteudoId, fonteId, similaridade })
    .from(conteudoChunks)
    .orderBy(cosineDistance(conteudoChunks.embedding, embeddingConsulta))
    .limit(limite);
}
```

`1 - cosineDistance` converte distância em score de similaridade (1 =
idêntico, 0 = ortogonal) — mais intuitivo para quem for consumir a API do
que a distância crua.

## 4. API

```http
POST /biblioteca-viva/buscar
Content-Type: application/json

{ "consulta": "o que é ownership em Rust", "limite": 5 }
```

Testado via `curl` durante a validação do scaffold: retorna `500` com
formato RFC 7807 hoje, porque `EmbeddingService.gerar()` ainda é stub. A
rota, a validação de entrada (`limite` entre 1 e 20, `consulta` com no
mínimo 3 caracteres) e a query de banco estão prontas e vão funcionar assim
que o `EmbeddingService` for implementado — nenhuma mudança adicional
necessária neste módulo.

## 5. Próximo passo concreto

Implementar `EmbeddingService.gerar()` (`06-rag.md §2.4`) é o único bloqueio
para este módulo funcionar de ponta a ponta. É provavelmente o menor
próximo passo de implementação de todo o projeto — vale considerar como
primeira tarefa real de código, dado que valida o pipeline de RAG inteiro
com o mínimo de trabalho novo.
