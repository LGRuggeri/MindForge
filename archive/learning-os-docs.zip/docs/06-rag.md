# 06 — RAG (Retrieval-Augmented Generation)

**Status:** parcialmente implementado. A indexação e a busca por
similaridade (`biblioteca-viva`) estão codificadas e testadas — ver
`11-biblioteca-viva.md`. A geração de embeddings reais, a pesquisa online
(`research`) e a síntese de conteúdo (`synthesizer`) ainda são TODO.

## 1. Por que RAG neste projeto

O Tutor IA precisa responder com contexto de tudo que já foi estudado —
inclusive conteúdo de módulos antigos, de trilhas de outros objetivos. Sem
RAG, cada resposta dependeria só do conhecimento geral do modelo de
linguagem, sem "lembrar" do que já foi ensinado especificamente para o
usuário. É isso que torna a Biblioteca Viva viva, em vez de um repositório
estático.

## 2. Pipeline completo

```text
fontes_pesquisa  (Research Engine busca online)
      ↓
conteudos        (Synthesizer sintetiza a partir das fontes)
      ↓
conteudo_chunks  (quebra em pedaços + embedding)
      ↓
busca por similaridade de cosseno  (Biblioteca Viva)
      ↓
contexto montado no prompt do Tutor IA
```

### 2.1 Research Engine (`research` — TODO)

Busca documentação oficial, livros, artigos e vídeos relacionados ao módulo
da trilha em andamento, seguindo a priorização definida em
`01-filosofia.md` (documentação oficial primeiro). Cada fonte encontrada
vira uma linha em `fontes_pesquisa`, com `confiabilidade_score` atribuído
pelo próprio agente.

### 2.2 Synthesizer (`synthesizer` — TODO)

Lê as fontes de um módulo e produz `conteudos.corpo_markdown` original —
não uma cópia das fontes, uma explicação didática que as referencia
(`conteudo_fontes`). Ver `09-gerador-de-conteudo.md` para o fluxo completo,
incluindo a revisão pelo agente `reviewer`.

### 2.3 Chunking e indexação (`biblioteca-viva` — implementado)

Estratégia definida em `04-modelagem-dados.md §3.4`: **500–800 tokens por
chunk, com sobreposição de 50–100 tokens**. O código de indexação
(`BibliotecaVivaRepository.indexarChunk`) já existe e foi testado; falta
apenas o componente que decide *onde* cortar o texto em chunks — hoje isso
seria feito manualmente antes de chamar `indexarChunk`, e precisa virar
parte do fluxo do `synthesizer` quando ele for implementado.

### 2.4 Geração de embeddings (`EmbeddingService` — stub)

`modules/biblioteca-viva/embedding.service.ts` define o contrato
(`gerar(texto: string): Promise<number[]>`) mas lança erro — é o único
ponto do sistema acoplado ao provedor de embeddings escolhido. Implementar
aqui quando o provedor for decidido; a dimensão do vetor retornado precisa
bater exatamente com `EMBEDDING_DIMENSIONS` em
`database/schema/conteudos.schema.ts` (hoje `1536`, compatível com
`text-embedding-3-small`).

### 2.5 Busca por similaridade (`biblioteca-viva` — implementado e testado)

```ts
// BibliotecaVivaRepository.buscarSimilares — código real, já testado
const similaridade = sql<number>`1 - (${cosineDistance(
  conteudoChunks.embedding,
  embeddingConsulta,
)})`;

return this.db
  .select({ id, texto, conteudoId, fonteId, similaridade })
  .from(conteudoChunks)
  .orderBy(cosineDistance(conteudoChunks.embedding, embeddingConsulta))
  .limit(limite);
```

Testado via `POST /biblioteca-viva/buscar` — a rota está no ar, só depende
do `EmbeddingService` real para retornar resultados de fato (hoje retorna
erro 500 controlado, formato RFC 7807).

### 2.6 Montagem do contexto para o Tutor IA (`tutor` — TODO)

Ainda não decidido: quantos chunks entram no prompt (o `limite` do DTO
default é 5), como lidar com chunks de módulos muito antigos vs. recentes,
e se o `teacher` deve citar a fonte de cada trecho usado na resposta. Fica
como parte do design do módulo `tutor` quando ele for implementado.

## 3. Configuração do índice vetorial

Índice HNSW (`vector_cosine_ops`), criado com os parâmetros padrão do
pgvector (`m=16`, `ef_construction=64`). Adequado para o volume de uso
pessoal atual. Se a Biblioteca Viva crescer para centenas de milhares de
chunks e a latência de busca começar a incomodar, os parâmetros podem ser
ajustados — não antes, seguindo o princípio de simplicidade de
`01-filosofia.md`.
