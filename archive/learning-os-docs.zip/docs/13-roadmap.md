# 13 — Roadmap

Consolida as fases macro definidas em `00-visao.md` em entregas concretas,
com o estado real de cada item — atualizado pela última vez após o scaffold
do backend (`learning-os-api.zip`).

## Fase 1 — Fundamentos

| Item | Status |
|---|---|
| Modelagem de dados (21 tabelas, validada em Postgres + pgvector real) | ✅ pronto — `04-modelagem-dados.md` |
| Scaffold do backend (NestJS + Drizzle, compilando e testado via HTTP) | ✅ pronto — `learning-os-api.zip` |
| Módulo Perfil (CRUD completo) | ✅ pronto |
| Módulo Biblioteca Viva (indexação + busca vetorial) | ✅ pronto, falta só `EmbeddingService` real — `11-biblioteca-viva.md §5` |
| `EmbeddingService` real (integração com provedor de embeddings) | ⬜ TODO — próximo passo mais concreto do projeto |
| Módulo Objetivos + Planner (geração de trilha) | ⬜ TODO — `08-planejador.md` |
| Módulo Tutor IA (RAG conversacional) | ⬜ TODO — `06-rag.md §2.6` |
| Autenticação | ⬜ TODO — hoje todas as rotas estão abertas |
| Dashboard (frontend) | ⬜ TODO — nenhum código de frontend ainda existe |

**Critério de conclusão da Fase 1:** o usuário consegue registrar um
objetivo, receber uma trilha gerada pelo Planner, e conversar com o Tutor
IA sobre o primeiro módulo, com contexto real vindo da Biblioteca Viva —
tudo autenticado e visível num dashboard mínimo.

## Fase 2 — Conteúdo e prática

| Item | Status |
|---|---|
| Research Engine (busca de fontes online) | ⬜ TODO — `06-rag.md §2.1` |
| Synthesizer (geração de conteúdo) + Reviewer | ⬜ TODO — `09-gerador-de-conteudo.md` |
| Chunking automático (parte do Synthesizer) | ⬜ TODO — `06-rag.md §2.3` |
| Diário de Aprendizagem | ⬜ TODO — `12-diario-aprendizagem.md` |
| Exercícios (geração + correção) | ⬜ TODO — `10-avaliacoes.md` |
| Revisão espaçada | ⬜ TODO — schema pronto (`revisao_espacada`), nenhuma lógica de agendamento implementada |
| Fila de jobs real (`pg-boss`, hoje stub em `JobsModule`) | ⬜ TODO — necessário para Research/Synthesizer assíncronos |

**Critério de conclusão da Fase 2:** um objetivo completo — da pesquisa à
prática — roda sem intervenção manual em nenhuma etapa, e itens entram
automaticamente na fila de revisão espaçada conforme o usuário erra ou
acerta exercícios.

## Fase 3 — Inteligência de longo prazo

| Item | Status |
|---|---|
| Knowledge Graph (atualização automática de progresso) | ⬜ TODO — modelo pronto, lógica não — `07-knowledge-graph.md §3` |
| Visualização do grafo (React Flow) | ⬜ TODO — `07-knowledge-graph.md §4` |
| Avaliações compostas (simulados multi-módulo) | ⬜ TODO — `10-avaliacoes.md §3` |
| Projetos inteligentes (exercícios tipo `projeto`) | ⬜ TODO |
| Correção de exercícios de código (sandbox de execução) | ⬜ TODO — `10-avaliacoes.md §5`, decisão de infraestrutura ainda em aberto |

**Critério de conclusão da Fase 3:** o Knowledge Graph reflete com precisão
o que o usuário sabe e não sabe, sem input manual, e serve de insumo direto
para o Planner decidir o próximo objetivo de estudo.

## Ordem sugerida dentro da Fase 1

Dado o estado atual, a sequência de menor esforço para maior valor
entregue é:

1. `EmbeddingService` real — desbloqueia a Biblioteca Viva por completo,
   menor esforço de todos os itens pendentes.
2. Autenticação — necessária antes de qualquer outro módulo expor dado
   pessoal de verdade.
3. Módulo Objetivos + Planner — sem trilha, não há o que o Tutor IA
   contextualizar.
4. Tutor IA — fecha o loop mínimo de valor da Fase 1.
5. Dashboard — só depois de haver dado real para mostrar.

Esta ordem é uma sugestão, não uma regra fixa — revisar conforme o
Knowledge OS avança e novas prioridades pessoais surgirem (`01-filosofia.md`:
evolução incremental, não plano rígido de anos).
