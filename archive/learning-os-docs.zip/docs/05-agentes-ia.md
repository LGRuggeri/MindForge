# 05 — Agentes de IA

**Status:** especificação de design. Nenhum agente está implementado ainda —
os módulos `planner`, `research`, `synthesizer`, `tutor` e `agentes` no
backend são esqueletos (ver `learning-os-api/README.md`).

## Visão geral

Cinco agentes especializados, cada um responsável por uma etapa do fluxo
descrito em `00-visao.md`. O identificador interno de cada agente (usado na
coluna `agentes_execucoes.agente`) nem sempre coincide com o nome do módulo
de domínio correspondente:

| Agente (`agentes_execucoes.agente`) | Módulo de domínio | Responsabilidade |
|---|---|---|
| `planner` | `planner` | Gera e replaneja trilhas de estudo. Ver `08-planejador.md`. |
| `researcher` | `research` | Busca fontes online confiáveis. Ver `06-rag.md`. |
| `teacher` | `tutor` | Responde dúvidas usando RAG sobre a Biblioteca Viva. Ver `06-rag.md` e `11-biblioteca-viva.md`. |
| `evaluator` | `exercicios-avaliacoes` | Corrige tentativas e consolida resultados de avaliação. Ver `10-avaliacoes.md`. |
| `reviewer` | `synthesizer` | Revisa conteúdo sintetizado antes de marcá-lo como `publicado`. Ver `09-gerador-de-conteudo.md`. |

O diário (`12-diario-aprendizagem.md`) e o knowledge graph
(`07-knowledge-graph.md`) **não têm agente dedicado** no enum atual — ver
observação na seção 4.

## 1. Contrato comum

Toda execução de agente é registrada em `agentes_execucoes`
(`04-modelagem-dados.md §3.9`) com `entrada`, `saída`, `modelo_usado`,
`tokens_utilizados`, `duracao_ms` e `status`. Isso não é opcional — é a
única forma de depurar por que um plano saiu ruim ou uma correção ficou
incoerente, num sistema onde múltiplos agentes tomam decisões em cadeia sem
revisão humana em cada etapa.

Padrão recomendado para a implementação (a definir quando cada agente for
codificado): um `AgenteExecutor` genérico no módulo `agentes` que envolve a
chamada ao LLM, mede duração, captura erro e grava o registro — para que
nenhum dos cinco agentes precise reimplementar esse logging manualmente.

## 2. Prompts

Os prompts de cada agente vivem fora deste documento, em arquivos próprios
(`prompts/planner.md`, `prompts/researcher.md`, `prompts/teacher.md`,
`prompts/evaluator.md`, `prompts/reviewer.md`), para poderem ser versionados
e iterados independentemente da documentação de arquitetura. **Ainda não
escritos** — serão criados quando cada agente entrar em desenvolvimento,
junto com o código que os consome.

## 3. Execução: síncrona ou assíncrona?

| Agente | Modo recomendado | Por quê |
|---|---|---|
| `teacher` | Síncrono (na requisição HTTP) | O usuário espera uma resposta interativa; a busca vetorial é rápida (índice HNSW). |
| `planner` | Assíncrono (fila) | Pode envolver pesquisa preliminar antes de montar a trilha; latência não é crítica. |
| `researcher` | Assíncrono (fila) | Chamadas de rede a fontes externas, potencialmente lentas ou instáveis. |
| `reviewer` | Assíncrono (fila) | Roda depois que o `synthesizer` termina; não bloqueia o usuário. |
| `evaluator` | Depende do tipo de exercício | Correção objetiva pode ser síncrona; correção dissertativa via LLM tende a ser mais rápida síncrona também, mas avaliações compostas (múltiplos exercícios) fazem mais sentido assíncronas. A decidir na implementação. |

A fila usada é a mesma `JobsModule` (`pg-boss`/`graphile-worker`) descrita em
`02-arquitetura.md` e `03-stack-tecnologica.md` — nenhum agente introduz uma
dependência de infraestrutura nova.

## 4. Ponto em aberto: diário e knowledge graph

Nem `diario_aprendizagem.recomendacoes_ia` nem a atualização de
`competencia_progresso` têm um agente dedicado no enum atual de
`agentes_execucoes`. Duas opções a decidir quando esses módulos forem
implementados:

1. Reaproveitar o `teacher` para gerar as recomendações do diário (é
   essencialmente uma síntese conversacional).
2. Adicionar um sexto valor ao `CHECK` de `agentes_execucoes.agente` (ex:
   `'summarizer'`) — migration simples, mas é uma decisão que vale registrar
   como ADR quando tomada (`14-decisoes-arquiteturais.md`).

Não decidido agora, de propósito: forçar essa decisão sem ter implementado
o diário ainda seria especular sem informação suficiente.
