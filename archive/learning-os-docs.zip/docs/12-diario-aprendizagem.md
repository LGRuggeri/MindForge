# 12 — Diário de Aprendizagem

**Status:** TODO. Módulo `diario` no backend é esqueleto.

## 1. Responsabilidade

Um registro por dia de estudo (`diario_aprendizagem`, `UNIQUE (perfil_id,
data)`): tempo investido, módulos estudados (`diario_modulos`),
dificuldades, conquistas e recomendações geradas pela IA. É o componente
mais próximo de um "log pessoal" do sistema — a diferença entre o Learning
OS lembrar genericamente o que foi estudado e lembrar *como* foi estudar
aquilo.

## 2. Quando um registro é criado

Duas abordagens possíveis, não decidido qual (ou se as duas coexistem):

1. **Ao final de uma sessão de estudo** — o usuário interage com o Tutor
   IA, responde exercícios, e ao encerrar a sessão o sistema resume o que
   aconteceu.
2. **Job agendado diário** (via `pg-boss`/`graphile-worker`, mesma fila de
   `02-arquitetura.md`) — roda uma vez por dia, olha para toda atividade
   registrada (`tentativas_exercicio.respondido_em`,
   `agentes_execucoes.criado_em` do dia) e consolida um resumo.

A opção 2 é mais simples de implementar corretamente (não depende de
detectar "fim de sessão", que é um conceito ambíguo numa API stateless) e
parece o ponto de partida mais razoável.

## 3. Quem escreve o quê

- `tempo_investido_min`, `dificuldades`, `conquistas`: podem vir tanto de
  input direto do usuário quanto de inferência automática (tempo entre
  primeira e última interação do dia, exercícios errados como sinal de
  dificuldade).
- `recomendacoes_ia`: gerado por IA — mas por qual agente é uma pergunta em
  aberto, já registrada em `05-agentes-ia.md §4`. Reaproveitar o `teacher`
  é o caminho mais simples até haver razão concreta para um agente novo.

## 4. Uso posterior

O diário não é só um registro passivo — é insumo para o `planner` decidir
se um replanejamento é necessário (`08-planejador.md §4`: "dificuldades
recorrentes registradas no diário" é um sinal tão válido quanto uma
avaliação formal com nota baixa).

## 5. Pontos em aberto

- Formato de `dificuldades` e `conquistas`: texto livre no schema atual.
  Pode valer a pena estruturar como tags ligadas a `competencias` no
  futuro, para alimentar o Knowledge Graph automaticamente — mas isso é
  especulação sobre um módulo que ainda não existe; não vale decidir agora.
- Sem endpoint definido ainda. Provavelmente `GET /diario?data=` e
  `GET /diario/streak` (sequência de dias consecutivos estudando) fazem
  sentido para o dashboard da Fase 1, mas isso é decisão de frontend
  (`13-roadmap.md`), não deste documento.
