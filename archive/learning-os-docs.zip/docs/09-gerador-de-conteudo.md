# 09 — Gerador de Conteúdo (Synthesizer)

**Status:** TODO. Módulo `synthesizer` no backend é esqueleto. O que existe
pronto e testado é o destino do conteúdo gerado (indexação vetorial, ver
`11-biblioteca-viva.md`), não a geração em si.

## 1. Responsabilidade

Para cada `modulo_trilha`, lê as `fontes_pesquisa` coletadas pelo
`research` e produz `conteudos.corpo_markdown` — material didático
original, não uma colagem das fontes. Cada conteúdo cita as fontes usadas
via `conteudo_fontes`.

## 2. Fluxo

```text
fontes_pesquisa (do módulo)
      ↓ Synthesizer lê e sintetiza
conteudos.status = 'rascunho'
      ↓ Reviewer avalia
conteudos.status = 'revisado' | de volta para 'rascunho' com feedback
      ↓ (se revisado)
conteudos.status = 'publicado'
      ↓
chunking + indexação vetorial (biblioteca-viva)
```

O agente `reviewer` (ver `05-agentes-ia.md`) existe especificamente para
esta etapa de controle de qualidade — nenhum conteúdo deveria ir direto de
`rascunho` para uso no Tutor IA sem passar por essa checagem, dado que o
Synthesizer é o único agente cuja saída o usuário vai efetivamente estudar
como verdade.

## 3. Priorização de fontes

Segue o princípio de `01-filosofia.md`: documentação oficial primeiro,
depois livros e artigos técnicos, só então outras fontes. O campo
`fontes_pesquisa.confiabilidade_score` (atribuído pelo `research`) pode ser
usado pelo Synthesizer para decidir peso relativo entre fontes conflitantes
— por exemplo, quando duas fontes descrevem o mesmo conceito de formas
levemente diferentes.

## 4. Versionamento

`conteudos.versao` permite regenerar um conteúdo (por exemplo, se novas
fontes mais atualizadas aparecerem, ou se o Reviewer rejeitar repetidamente
a versão atual) sem perder o histórico do que já foi estudado — importante
porque `conteudo_chunks` de versões antigas podem já ter sido usados em
respostas do Tutor IA registradas em `diario_aprendizagem` ou
`agentes_execucoes`.

## 5. Pontos em aberto

- Tamanho alvo de um `conteudo` por módulo: não definido. Precisa ser
  suficiente para ensinar o `objetivo_aprendizagem` do módulo sem virar um
  livro-texto — provavelmente algo entre 1.000 e 3.000 palavras, a calibrar
  na prática.
- Critério de rejeição do `reviewer`: não definido. Precisa de um rubric
  mínimo (precisão factual, cobertura do objetivo do módulo, clareza) antes
  de escrever o prompt em `prompts/reviewer.md`.
